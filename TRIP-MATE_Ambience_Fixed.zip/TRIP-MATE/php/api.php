<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
require_once __DIR__.'/config.php';
function out(int $status, array $body): never { http_response_code($status); echo json_encode($body); exit; }
function body(): array { $v=json_decode(file_get_contents('php://input'),true); return is_array($v)?$v:$_POST; }
function loggedIn(): int { if (empty($_SESSION['user_id'])) out(401,['ok'=>false,'error'=>'Please log in first.']); return (int)$_SESSION['user_id']; }
try {
  $action = $_GET['action'] ?? '';
  $data = body();
  if ($action === 'register' && $_SERVER['REQUEST_METHOD']==='POST') {
    $name=trim((string)($data['name']??'')); $email=strtolower(trim((string)($data['email']??''))); $password=(string)($data['password']??'');
    if (mb_strlen($name)<2 || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($password)<8) out(422,['ok'=>false,'error'=>'Enter a name, valid email, and password of at least 8 characters.']);
    $q=db()->prepare('INSERT INTO users (name,email,password_hash) VALUES (?,?,?)');
    try {$q->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT)]);} catch(PDOException $e){ if($e->getCode()==='23000') out(409,['ok'=>false,'error'=>'An account with this email already exists.']); throw $e; }
    session_regenerate_id(true); $_SESSION['user_id']=(int)db()->lastInsertId(); out(201,['ok'=>true,'user'=>['id'=>$_SESSION['user_id'],'name'=>$name,'email'=>$email]]);
  }
  if ($action === 'login' && $_SERVER['REQUEST_METHOD']==='POST') {
    $email=strtolower(trim((string)($data['email']??''))); $q=db()->prepare('SELECT id,name,email,password_hash FROM users WHERE email=?'); $q->execute([$email]); $u=$q->fetch();
    if(!$u || !password_verify((string)($data['password']??''),$u['password_hash'])) out(401,['ok'=>false,'error'=>'Email or password is incorrect.']);
    session_regenerate_id(true); $_SESSION['user_id']=(int)$u['id']; out(200,['ok'=>true,'user'=>['id'=>(int)$u['id'],'name'=>$u['name'],'email'=>$u['email']]]);
  }
  if ($action === 'logout' && $_SERVER['REQUEST_METHOD']==='POST') { $_SESSION=[]; session_destroy(); out(200,['ok'=>true]); }
  if ($action === 'me' && $_SERVER['REQUEST_METHOD']==='GET') { if(empty($_SESSION['user_id'])) out(200,['ok'=>true,'user'=>null]); $q=db()->prepare('SELECT id,name,email FROM users WHERE id=?'); $q->execute([$_SESSION['user_id']]); out(200,['ok'=>true,'user'=>$q->fetch()]); }
  if ($action === 'trip' && $_SERVER['REQUEST_METHOD']==='POST') {
    $name=trim((string)($data['name']??'')); $email=strtolower(trim((string)($data['email']??''))); $phone=trim((string)($data['phone']??'')); $date=(string)($data['travel_date']??''); $time=(string)($data['departure_time']??''); $travellers=filter_var($data['travellers']??1,FILTER_VALIDATE_INT); $type=trim((string)($data['trip_type']??'Solo')); $interests=$data['interests']??[]; $notes=trim((string)($data['notes']??''));
    if(mb_strlen($name)<2 || !filter_var($email,FILTER_VALIDATE_EMAIL) || !preg_match('/^[0-9+() .-]{7,20}$/',$phone) || !$date || $date<date('Y-m-d') || !$travellers || $travellers<1 || $travellers>20 || !is_array($interests)) out(422,['ok'=>false,'error'=>'Please check your name, email, phone, travel date and traveller count.']);
    $q=db()->prepare('INSERT INTO trip_requests (user_id,name,email,phone,travel_date,departure_time,travellers,trip_type,interests,notes,status) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
    $q->execute([$_SESSION['user_id']??null,$name,$email,$phone,$date,$time?:null,$travellers,$type,json_encode(array_slice($interests,0,10)),mb_substr($notes,0,300),'pending']);
    out(201,['ok'=>true,'id'=>(int)db()->lastInsertId(),'status'=>'pending','message'=>'Your trip request has been saved. This is a request, not a confirmed booking.']);
  }
  if ($action === 'my-trips' && $_SERVER['REQUEST_METHOD']==='GET') { $uid=loggedIn(); $q=db()->prepare('SELECT id,name,email,travel_date,departure_time,travellers,trip_type,interests,notes,status,created_at FROM trip_requests WHERE user_id=? ORDER BY created_at DESC'); $q->execute([$uid]); out(200,['ok'=>true,'trips'=>$q->fetchAll()]); }
  if ($action === 'wishlist' && $_SERVER['REQUEST_METHOD']==='GET') { $uid=loggedIn(); $q=db()->prepare('SELECT destination_id,created_at FROM wishlist WHERE user_id=? ORDER BY created_at DESC'); $q->execute([$uid]); out(200,['ok'=>true,'items'=>$q->fetchAll()]); }
  if ($action === 'wishlist' && $_SERVER['REQUEST_METHOD']==='POST') { $uid=loggedIn(); $dest=trim((string)($data['destination_id']??'')); if(!preg_match('/^[a-zA-Z0-9_-]{1,80}$/',$dest)) out(422,['ok'=>false,'error'=>'Invalid destination.']); $q=db()->prepare('INSERT IGNORE INTO wishlist(user_id,destination_id) VALUES(?,?)'); $q->execute([$uid,$dest]); out(200,['ok'=>true]); }
  if ($action === 'wishlist' && $_SERVER['REQUEST_METHOD']==='DELETE') { $uid=loggedIn(); $dest=trim((string)($_GET['destination_id']??'')); $q=db()->prepare('DELETE FROM wishlist WHERE user_id=? AND destination_id=?'); $q->execute([$uid,$dest]); out(200,['ok'=>true]); }
  out(404,['ok'=>false,'error'=>'Unknown action or unsupported HTTP method.']);
} catch(Throwable $e) { error_log($e->__toString()); out(500,['ok'=>false,'error'=>'Server/database error. Check PHP error log and database setup.']); }
